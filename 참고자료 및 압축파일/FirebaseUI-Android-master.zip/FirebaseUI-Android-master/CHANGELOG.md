Release notes moved to [Releases](https://github.com/firebase/FirebaseUI-Android/releases)
