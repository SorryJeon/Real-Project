# Firebase Android Snippets

This repository holds code snippets used in Android documentation
on [firebase.google.com](https://firebase.google.com/docs/).

## Contributing

We love contributions! See [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.


[![Actions Status][gh-actions-badge]][gh-actions]

[gh-actions]: https://github.com/firebase/snippets-android/actions
[gh-actions-badge]: https://github.com/firebase/snippets-android/workflows/Android%20CI/badge.svg