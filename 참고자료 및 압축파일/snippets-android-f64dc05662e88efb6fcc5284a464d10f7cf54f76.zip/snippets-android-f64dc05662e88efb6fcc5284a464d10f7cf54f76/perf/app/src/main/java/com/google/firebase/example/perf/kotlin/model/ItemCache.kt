package com.google.firebase.example.perf.kotlin.model

class ItemCache {
    fun fetch(name: String): Item? {
        return null
    }
}
