package com.google.firebase.example.perf.kotlin.model

class User {
    fun getEmailAddress(): String {
        return ""
    }
}
