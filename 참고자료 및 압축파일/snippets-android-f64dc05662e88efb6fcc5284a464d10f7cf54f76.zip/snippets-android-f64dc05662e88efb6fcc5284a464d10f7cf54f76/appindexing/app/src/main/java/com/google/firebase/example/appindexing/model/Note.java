package com.google.firebase.example.appindexing.model;

public  class Note {
    public String getText() {
        return "";
    }

    public String getTitle() {
        return "";
    }

    public String getNoteUrl() {
        return "";
    }
}
