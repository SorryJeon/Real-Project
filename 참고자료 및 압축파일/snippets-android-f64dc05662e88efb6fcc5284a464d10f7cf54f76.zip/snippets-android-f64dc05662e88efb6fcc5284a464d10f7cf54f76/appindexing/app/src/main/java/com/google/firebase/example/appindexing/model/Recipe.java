package com.google.firebase.example.appindexing.model;

public class Recipe {
    public String getTitle() {
        return "";
    }

    public Note getNote() {
        return null;
    }

    public String getNoteUrl() {
        return "";
    }
}
