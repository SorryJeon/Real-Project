package org.IF.first.meeatnowkotlin

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.facebook.*
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult

import kotlinx.android.synthetic.main.activity_login.*
import org.json.JSONObject
import java.util.*

class LoginActivity : AppCompatActivity() {
    // binding 객체
    private lateinit var accessToken: AccessToken
    // private lateinit var binding: ActivityLoginBinding
    private lateinit var result: FacebookCallback<LoginResult>
    private var isLoggedInWithFacebook: Boolean = false
    private lateinit var userEmail: String
    private lateinit var userName: String
    private lateinit var jobj1: JSONObject
    private lateinit var jobj2: JSONObject
    private lateinit var userPicture: String
    private var callbackManager: CallbackManager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        var facebookButton = findViewById<Button>(R.id.loginButton_facebook)

        facebookButton.setOnClickListener(View.OnClickListener {

            // 페이스북 콜백
            callbackManager = CallbackManager.Factory.create()
            LoginManager.getInstance()
                .logInWithReadPermissions(this, Arrays.asList("public_profile", "email"))
            LoginManager.getInstance().registerCallback(callbackManager,
                object : FacebookCallback<LoginResult> {
                    override fun onSuccess(loginResult: LoginResult) {

                        accessToken = loginResult.accessToken
                        isLoggedInWithFacebook = accessToken != null && !accessToken.isExpired()
                        requestMe(accessToken)
                    }

                    override fun onCancel() {

                    }

                    override fun onError(error: FacebookException?) {
                    }

                })
        })


    }

    fun requestMe(accessToken: AccessToken) {
        val request = GraphRequest.newMeRequest(accessToken) { `object`, response ->
            try {
                //here is the data that you want

                userEmail = `object`.getString("email")
                Log.e("TAGG", userEmail)
                userName = `object`.getString("name")
                Log.e("TAGG", userName)
                jobj1 = `object`.optJSONObject("picture")
                Log.e("TAGG", jobj1.toString())
                jobj2 = jobj1.optJSONObject("data")
                Log.e("TAGG", jobj2.toString())
                userPicture = jobj2.getString("url")
                Log.e("TAGG", userPicture)



            } catch (e: Exception) {
                e.printStackTrace()
            }

            goTomain()

        }

        val parameters = Bundle()
        parameters.putString("fields", "name,email,picture")
        request.parameters = parameters
        request.executeAsync()

    }

    fun goTomain() {
        var intent = Intent(this, MainActivity::class.java)
        intent.putExtra("isLoggedInWithFacebook", isLoggedInWithFacebook)
        startActivity(intent)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        callbackManager?.onActivityResult(requestCode, resultCode, data)
    }

    override fun onStart() {
        super.onStart()
        accessToken = AccessToken.getCurrentAccessToken()
        isLoggedInWithFacebook = accessToken != null && !accessToken.isExpired()

        if(isLoggedInWithFacebook){
            requestMe(accessToken)
        }
        else{

        }
    }
}
