package org.IF.first.meeatnowkotlin

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import java.security.MessageDigest


class MainActivity : AppCompatActivity() {

    private var isLoggedInWithFacebook: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // putExtra로 가져온 값 체크
        if(intent.hasExtra("isLoggedInWithFacebook")){
            isLoggedInWithFacebook = intent.getBooleanExtra("isLoggedInWithFacebook", true)
        }
        else{

        }

        var profileButton: Button = findViewById(R.id.profileButton)
        profileButton.setOnClickListener(View.OnClickListener {

            if(isLoggedInWithFacebook){

            }

            goToProfilePage()
        })
    }
    fun goToProfilePage(){
        var intent = Intent(getApplicationContext(), ProfileActivity::class.java)
        startActivity(intent)
    }
}
